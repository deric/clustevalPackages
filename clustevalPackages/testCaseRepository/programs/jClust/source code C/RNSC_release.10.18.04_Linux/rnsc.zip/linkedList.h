/******************************************************************************
*******************************************************************************
*******************************************************************************
// All files written by Andrew D. King, 2004, except some of the linked list
// classes, but I honestly can't remember where I got them.  Feel free to
// distribute this in its unaltered form.  The author takes no responsibility
// for loss of sanity resulting from poorly written or documented code.
//
// Compiled under Fedora Core 2 Linux using the GNU C++ compiler verision 2.96.
// Probably won't work with newer or older versions or under different
// operating systems.
//
// As of September, 2004, the author will be reachable at the Department of
// Computer Science, McGill University, Montreal, Quebec, Canada.  The email
// address andrew.king@utoronto.ca will probably be in service until at least
// mid-2005.  Feel free to send any comments.
*******************************************************************************
*******************************************************************************
******************************************************************************/

typedef struct List
{ 
	int Vertex;
	List* Next;
	List(){
		Next = NULL;
		Vertex = -1;
	}
};
typedef List* ListPtr;

class SLList
{
 private:
 public:
	SLList();
	~SLList();
	ListPtr SLList::Previous(long index);
	ListPtr SLList::Previous(ListPtr index);
	void SLList::AddANode();
	void SLList::AddAtHead();
	void SLList::Advance();
	void SLList::Rewind();
	void SLList::DeleteANode(ListPtr corpse);
	void SLList::DeleteANodeFast(ListPtr corpse, ListPtr corpsePrev);
	void SLList::PrintList();
	void SLList::RewindToHead();
	void SLList::InsertANodeAfter(ListPtr point);

	ListPtr Head, Tail, CurrentPtr;
	
};



typedef struct DListDouble
{ 
	long Vertex;
	long To;
	double Cost;
	DListDouble* Next;
	DListDouble* Previous;
	DListDouble(){
		Next = NULL;
		Previous = NULL;
		Vertex = -1;
		To = -1;
	}
};
typedef DListDouble* DListDoublePtr;

class DLListDouble
{
 private:
 public:
	DLListDouble();
	~DLListDouble();
	void DLListDouble::AddANode();
	void DLListDouble::Advance();
	void DLListDouble::Rewind();
	void DLListDouble::DeleteANode(DListDoublePtr corpse);
	void DLListDouble::PrintList();
	void DLListDouble::PrintListBackwards();
	void DLListDouble::RewindToHead();
	void DLListDouble::MoveToBefore(DListDoublePtr source, DListDoublePtr dest);
	void DLListDouble::MoveToAfter(DListDoublePtr source, DListDoublePtr dest);
	DListDoublePtr DLListDouble::InsertANodeBefore(DListDoublePtr point);
	DListDoublePtr DLListDouble::InsertANodeAfter(DListDoublePtr point);

	DListDoublePtr Head, Tail, CurrentPtr;
	
};


typedef struct PList
{
	DListDoublePtr Ptr;
	PList* Next;
	PList(){
		Next=NULL;
		Ptr=NULL;
	}
};
typedef PList* PListPtr;

class PLList
{
 private:
 public:
	PLList();
	~PLList();
	PListPtr PLList::Previous(PListPtr index);
	void PLList::AddANode();
	void PLList::AddAtHead();
	void PLList::Advance();
	void PLList::Rewind();
	void PLList::DeleteANode(PListPtr corpse);
	void PLList::DeleteANodeFast(PListPtr corpse, PListPtr corpsePrev);
	void PLList::PrintList();
	void PLList::RewindToHead();
	void PLList::InsertANodeAfter(PListPtr point);

	PListPtr Head, Tail, CurrentPtr;
	
};

//linkedList4.cpp
/*
typedef struct PListPlus
{
	DListDoublePtr Ptr;
	PListPlus* Next;
	int Count;
	PListPlus(){
		Next=NULL;
		Ptr=NULL;
		Count=-1;
	}
};
typedef PListPlus* PListPlusPtr;

class PLListPlus
{
 private:
 public:
	PLListPlus();
	~PLListPlus();
	PListPlusPtr PLListPlus::Previous(PListPlusPtr index);
	void PLListPlus::AddANode();
	void PLListPlus::AddAtHead();
	void PLListPlus::Advance();
	void PLListPlus::Rewind();
	void PLListPlus::DeleteANode(PListPlusPtr corpse);
	void PLListPlus::DeleteANodeFast(PListPlusPtr corpse, PListPlusPtr corpsePrev);
	void PLListPlus::PrintList();
	void PLListPlus::RewindToHead();
	void PLListPlus::InsertANodeAfter(PListPlusPtr point);

	PListPlusPtr Head, Tail, CurrentPtr;
	
};
*/

